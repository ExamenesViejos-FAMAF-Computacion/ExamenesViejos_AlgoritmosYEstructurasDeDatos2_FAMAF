#include <stdbool.h>
#include "even.h"

bool is_even_sorted(int array[], unsigned int length) {
    // -- Completar --
    return false;
}

